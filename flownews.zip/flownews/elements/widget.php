<?php
/**
 * flownews Theme
 *
 * Theme by: AD-Theme
 * Our portfolio: http://themeforest.net/user/ad-theme/portfolio
 *
 */
 
 require_once(get_template_directory() . '/elements/widget/archivies.php');
 require_once(get_template_directory() . '/elements/widget/categories.php');
 require_once(get_template_directory() . '/elements/widget/advertisement.php');
 require_once(get_template_directory() . '/elements/widget/author.php');
 require_once(get_template_directory() . '/elements/widget/mega-posts.php');
 require_once(get_template_directory() . '/elements/widget/social.php'); 
 require_once(get_template_directory() . '/elements/widget/slider-posts.php');
 require_once(get_template_directory() . '/elements/widget/tab.php');
 require_once(get_template_directory() . '/elements/widget/tag.php');
 require_once(get_template_directory() . '/elements/widget/instagram.php');
 require_once(get_template_directory() . '/elements/widget/contact.php');
 