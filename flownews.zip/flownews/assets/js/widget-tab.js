jQuery(document).ready(function($){
	$('.fnwp_title_recent').on('click', function(event) {
		$('.fnwp-recent').fadeIn();
		$('.fnwp-popular').css("display","none");
		$('.fnwp-tag').css("display","none");
		$('.fnwp_title_recent').addClass('fnwp_tab_active');
		$('.fnwp_title_popular').removeClass('fnwp_tab_active');
		$('.fnwp_title_tag').removeClass('fnwp_tab_active');
	});
	$('.fnwp_title_popular').on('click', function(event) {
		$('.fnwp-recent').css("display","none");
		$('.fnwp-popular').fadeIn();
		$('.fnwp-tag').css("display","none");
		$('.fnwp_title_popular').addClass('fnwp_tab_active');
		$('.fnwp_title_recent').removeClass('fnwp_tab_active');
		$('.fnwp_title_tag').removeClass('fnwp_tab_active');						
	});
	$('.fnwp_title_tag').on('click', function(event) {
		$('.fnwp-recent').css("display","none");
		$('.fnwp-popular').css("display","none");
		$('.fnwp-tag').fadeIn();
		$('.fnwp_title_tag').addClass('fnwp_tab_active');
		$('.fnwp_title_recent').removeClass('fnwp_tab_active');
		$('.fnwp_title_popular').removeClass('fnwp_tab_active');						
	});											
});